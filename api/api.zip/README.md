# webdevlistapi
### Youtube Playlist: [Complete Api Authentication with Laravel Passport](https://www.youtube.com/watch?v=OJtGeqgXwfo&list=PLzz9vf6075V1oNIpovX38TvLEXPAWCjwQ&index=2)
